
public class CalculatorTest {

	public static void main(String[] args) {
		Calculator c = new Calculator();
		System.out.println(3 == c.add(1, 2));
		System.out.println(-1 == c.subtract(1, 2));
		System.out.println(3 == c.multiply(1, 2));
		System.out.println(0 == c.divide(1, 2));
	}
}


